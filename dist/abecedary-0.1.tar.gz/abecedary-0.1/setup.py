from setuptools import setup, find_packages

setup(
    name='abecedary',
    version='0.1',
    packages=find_packages(),
    description='Library to get characters from the alphabet and symbols quickly',
    author='Trazeure',
    author_email='destiny72002@outlook.com',
    url='https://github.com/Trazeure/abecedary',
    install_requires=[],
)